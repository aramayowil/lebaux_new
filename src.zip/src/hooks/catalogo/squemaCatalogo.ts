export const SQUEMA = "opendata";
